# M4103 - TD n° 4


La page HTML de l'exercice est disponible [ici](index.php)
Le script JS de l'exercice est disponible [ici](script1.js)


------------


## 5) Exercice 1

### RSS Reader

1.  Quelle erreur obtenez-vous ?

    Il est impossible de charger le flux avec une requete Ajax sur un domaine extérieur (sans proxy)
    
2.  Pourquoi la solution ci-dessus de fonctionne pas ?

    Car il faut mettre en place un proxy pour pouvoir récupérer des valeurs de domaines extérieurs avec Ajax
    
------------

## 5) Exercice 2

### Fichiers Locaux

    Tout fonctionne correctement
    
------------

## 5) Exercice 3

### Proxy PHP

    Tout fonctionne correctement
    
------------

## 5) Exercice 4

### Analyse du contenu et mise en page

    Tout fonctionne correctement
    
------------

## 5) Exercice 5

### JSON

    Tout fonctionne correctement
    
------------