# M4103 - TD n° 3


La page HTML de l'exercice est disponible [ici](index.html)
Le script JS de l'exercice 1 est disponible [ici](script1.js)
Le script JS de l'exercice 2 est disponible [ici](script2.js)


------------


## 4) Exercice 1

### Taquin

1.  Que pouvez-vous dire de l’architecture de l’application ?

    Elle est architecturale.
    
    
## 5) Exercice 2

### 2048

    Pas de question